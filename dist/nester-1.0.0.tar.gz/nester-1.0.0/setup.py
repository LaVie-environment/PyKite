from distutils.core import setup

setup(
    name = 'nester',
    version = '1.0.0',
    py_modules = ['nester'],
    author = 'Seun',
    author_email = 'bellotaophyc@outlook.com',
    url = 'https://github.com/LaVie-environment',
    description = 'A simple printer pf nested lists',
)